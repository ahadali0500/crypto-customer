export const signInUserData = [
    {
        id: '21',
        avatar: '',
        userName: 'John Doe',
        email: 'test@gmail.com',
        authority: ['admin', 'user'],
        password: 'test@123',
        accountUserName: 'admin',
    },
]
