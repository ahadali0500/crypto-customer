export const NAV_ITEM_TYPE_TITLE = 'title'
export const NAV_ITEM_TYPE_COLLAPSE = 'collapse'
export const NAV_ITEM_TYPE_ITEM = 'item'
