export const APP_NAME = 'Ecme'
export const REDIRECT_URL_KEY = 'redirectUrl'
export const COOKIES_KEY = {
    THEME: 'theme',
    LOCALE: 'locale',
}
