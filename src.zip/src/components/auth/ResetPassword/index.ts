import ResetPassword from './ResetPassword'
export type { OnResetPasswordSubmitPayload } from './ResetPasswordForm'

export default ResetPassword
