'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import axios from 'axios'
import Input from '@/components/ui/Input'
import Button from '@/components/ui/Button'
import { FormItem } from '@/components/ui/Form'
import PasswordInput from '@/components/shared/PasswordInput'
import classNames from '@/utils/classNames'
import { z } from 'zod'
import type { ZodType } from 'zod'
import type { CommonProps } from '@/@types/common'
import type { ReactNode } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card1'

export type OnSignInPayload = {
    values: SignInFormSchema
    formData: FormData
    setSubmitting: (isSubmitting: boolean) => void
    setMessage: (message: string) => void
}

export type OnSignIn = (payload: OnSignInPayload) => void

interface SignInFormProps extends CommonProps {
    passwordHint?: string | ReactNode
    setMessage: (message: string) => void
    onSignIn?: OnSignIn
}

type SignInFormSchema = {
    email: string
    password: string
}

const validationSchema: ZodType<SignInFormSchema> = z.object({
    email: z.string().min(1, 'Please enter your email').email('Please enter a valid email'),
    password: z
        .string()
        .min(1, 'Please enter your password')
        .min(6, 'Password must be at least 6 characters'),
})

const SignInForm = ({ className, setMessage, onSignIn, passwordHint }: SignInFormProps) => {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [errors, setErrors] = useState<Partial<Record<keyof SignInFormSchema, string>>>({})
    const [isSubmitting, setSubmitting] = useState(false)
    const router = useRouter()

    const validate = (): boolean => {
        const result = validationSchema.safeParse({ email, password })
        if (!result.success) {
            const fieldErrors: any = {}
            for (const issue of result.error.issues) {
                const path = issue.path[0] as keyof SignInFormSchema
                fieldErrors[path] = issue.message
            }
            setErrors(fieldErrors)
            return false
        }
        setErrors({})
        return true
    }

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault()
        setMessage('')

        console.log('Sign In button clicked')
        if (!validate()) {
            console.log('Validation failed')
            return
        }

        console.log('Validation passed')
        setSubmitting(true)

        try {
            const formData = new FormData()
            formData.append('email', email)
            formData.append('password', password)

            const values = { email, password }

            const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL
            if (!backendUrl) {
                console.error('Backend URL is not defined in env variables')
                setMessage('Server configuration error.')
                return
            }

            console.log('Calling API:', `${backendUrl}/user/auth/login`)
            const response = await axios.post(
                `${backendUrl}/user/auth/login`,
                formData,
                {
                    headers: { 'Content-Type': 'multipart/form-data' },
                }
            )

            console.log('API response:', response.data)

            const { token } = response.data
            if (token && typeof window !== 'undefined') {
                localStorage.setItem('authToken', token)
                router.push('/create-ticket');
            }

            
        } catch (error: any) {
            console.error('Login error:', error)
            const message = error?.response?.data?.message || 'Login failed. Please try again.'
            setMessage(message)
        } finally {
            setSubmitting(false)
        }
    }

    return (
        <div className={className}>
            <Card className="bg-white/10 backdrop-blur-xl border-white/20 shadow-2xl">
                <CardHeader className="space-y-4 pb-6">
                    <CardTitle className="text-2xl font-bold text-center text-white">
                        Welcome Back
                    </CardTitle>
                    <CardDescription className="text-center text-slate-300">
                        Sign in to access your trading dashboard
                    </CardDescription>
                </CardHeader>

                <CardContent className="space-y-6">
                    <form onSubmit={handleSubmit}>
                        <FormItem
                            label="Email"
                            invalid={Boolean(errors.email)}
                            errorMessage={errors.email}
                        >
                            <Input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="Email"
                                autoComplete="email"
                                className="bg-white/5 border-white/20 text-white placeholder:text-slate-400 focus:border-yellow-400 focus:ring-yellow-400/20"
                            />
                        </FormItem>

                        <FormItem
                            label="Password"
                            invalid={Boolean(errors.password)}
                            errorMessage={errors.password}
                            className={classNames(
                                passwordHint ? 'mb-0' : '',
                                errors.password ? 'mb-8' : ''
                            )}
                        >
                            <PasswordInput
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="Password"
                                autoComplete="current-password"
                                className="bg-white/5 border-white/20 text-white placeholder:text-slate-400 focus:border-yellow-400 focus:ring-yellow-400/20"
                            />
                        </FormItem>

                        {passwordHint}

                        <Button
                            block
                            loading={isSubmitting}
                            variant="solid"
                            type="submit"
                            disabled={isSubmitting}
                        >
                            {isSubmitting ? 'Signing in...' : 'Sign In'}
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    )
}

export default SignInForm
