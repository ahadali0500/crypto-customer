import SignUp from './SignUp'
export type { OnSignUpPayload } from './SignUpForm'

export default SignUp
