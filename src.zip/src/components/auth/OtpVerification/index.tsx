import OtpVerification from './OtpVerification'

export default OtpVerification
