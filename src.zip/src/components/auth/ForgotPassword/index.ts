import ForgotPassword from './ForgotPassword'
export type { OnForgotPasswordSubmitPayload } from './ForgotPasswordForm'

export default ForgotPassword
