import ThemeConfigurator from '@/components/template/ThemeConfigurator'

const SidePanelContent = () => {
    return <ThemeConfigurator />
}

export default SidePanelContent
