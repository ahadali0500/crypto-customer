import ThemeConfigurator from './ThemeConfigurator'

export default ThemeConfigurator
