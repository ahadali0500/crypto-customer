import Skeleton from './Skeleton'

export type { SkeletonProps } from './Skeleton'
export { Skeleton }

export default Skeleton
