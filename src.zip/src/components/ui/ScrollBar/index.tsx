import ScrollBar from './ScrollBar'

export type { ScrollBarProps, ScrollBarRef } from './ScrollBar'
export { ScrollBar }

export default ScrollBar
