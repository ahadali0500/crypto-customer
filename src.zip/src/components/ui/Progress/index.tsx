import Progress from './Progress'

export type { ProgressProps } from './Progress'
export { Progress }

export default Progress
