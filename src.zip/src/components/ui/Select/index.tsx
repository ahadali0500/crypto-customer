import Select from './Select'
import Option from './Option'

export type { SelectProps } from './Select'
export { Select, Option }

export default Select
