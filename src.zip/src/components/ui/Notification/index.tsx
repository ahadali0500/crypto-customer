import Notification from './Notification'

export type { NotificationProps } from './Notification'
export { Notification }

export default Notification
