import {
    PiHouseLineDuotone,
    PiArrowsInDuotone,
    PiAcornDuotone,
} from 'react-icons/pi'
import { MdCurrencyExchange } from "react-icons/md";
import { IoTicketOutline,IoTicket } from "react-icons/io5";

import { FaFileInvoiceDollar } from "react-icons/fa6";


import type { JSX } from 'react'

export type NavigationIcons = Record<string, JSX.Element>

const navigationIcon: NavigationIcons = {
    home: <PiHouseLineDuotone />,
    singleMenu: <PiAcornDuotone />,
    collapseMenu: <PiArrowsInDuotone />,
    exchange: <MdCurrencyExchange />,
    deposit: <MdCurrencyExchange />,
    ticket:<IoTicketOutline />,
    Viewticket:<IoTicket />,
    invoice: <FaFileInvoiceDollar />,
     transaction: <FaFileInvoiceDollar />
}

export default navigationIcon
