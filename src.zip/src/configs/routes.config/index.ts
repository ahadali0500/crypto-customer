export { protectedRoutes, publicRoutes, authRoutes } from './routes.config'
