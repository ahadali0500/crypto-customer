import navigationConfig from '@/configs/navigation.config'

export async function getNavigation() {
    return navigationConfig
}
