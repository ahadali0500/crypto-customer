'use server'

import type { SignInCredential } from '@/@types/auth'
import axios from 'axios'

const validateCredential = async (values: SignInCredential) => {
  const formData = new FormData()
  formData.append('email', values.email)
  formData.append('password', values.password)

  try {
    const response = await axios.post(`${process.env.NEXT_PUBLIC_BACKEND_URL}/user/auth/login`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })

    const data = response.data

    return {
      id: data.user?.id || data.id,
      email: data.user?.email || data.email,
      userName: data.user?.username || data.username || values.email.split('@')[0],
      avatar: data.user?.avatar || data.avatar || '',
      token: data.token || data.access_token
    }

  } catch (error: any) {
    console.error('Authentication failed:', error.response?.data || error.message)
    return null
  }
}

export default validateCredential
