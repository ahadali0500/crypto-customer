import ForgotPasswordClient from './_components/ForgotPasswordClient'

const Page = () => {
    return <ForgotPasswordClient />
}

export default Page
