import SignInClient from './_components/SignInClient'

const Page = () => {
    return <SignInClient />
}

export default Page
