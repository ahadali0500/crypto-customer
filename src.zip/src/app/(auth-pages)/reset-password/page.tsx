import ResetPasswordClient from './_components/ResetPasswordClient'

const Page = () => {
    return <ResetPasswordClient />
}

export default Page
