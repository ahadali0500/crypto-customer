import SignUpClient from './_components/SignUpClient'

const Page = () => {
    return <SignUpClient />
}

export default Page
