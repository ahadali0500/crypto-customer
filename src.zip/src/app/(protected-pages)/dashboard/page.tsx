import React from 'react'

export const Page = () => {
  return (
    <div>Dashboard page</div>
  )
}
