'use client'

import React, { useEffect, useState } from 'react'
import { Button, Dialog, Input } from '@/components/ui'
import Dropdown from '@/components/ui/Dropdown/Dropdown'
import DropdownItem from '@/components/ui/Dropdown/DropdownItem'
import DataTable, { ColumnDef } from '@/components/shared/DataTable'
import { useRouter, useSearchParams } from 'next/navigation'
import Image from 'next/image'

type Transaction = {
    id: number
    date: string
    asset: string
    amount: string
    value: string
    fee: string
    status: string
}

const transactions: Transaction[] = [
    {
        id: 3101,
        date: '2025-06-02',
        asset: 'ETH',
        amount: '+0.0393185 ETH',
        value: '$100.00',
        fee: '0%',
        status: 'Processing',
    },
    {
        id: 3100,
        date: '2025-06-02',
        asset: 'BTC',
        amount: '+0.0009594 BTC',
        value: '$100.00',
        fee: '0%',
        status: 'Processing',
    },
]

const statusColorMap: Record<string, string> = {
    Processing: 'bg-yellow-200 text-yellow-800',
    Completed: 'bg-green-200 text-green-800',
    Failed: 'bg-red-200 text-red-800',
}

const columns: ColumnDef<Transaction>[] = [
    {
        header: 'ID',
        accessorKey: 'id',
        cell: ({ row }) => <span className="font-semibold">#{row.original.id}</span>,
    },
    {
        header: 'Date',
        accessorKey: 'date',
    },
    {
        header: 'Base Asset',
        accessorKey: 'asset',
    },
    {
        header: 'Amount',
        accessorKey: 'amount',
        cell: ({ getValue }) => (
            <span className="text-green-600 font-medium">{getValue() as string}</span>
        ),
    },
    {
        header: 'Value',
        accessorKey: 'value',
    },
    {
        header: 'Fee %',
        accessorKey: 'fee',
    },
    {
        header: 'Status',
        accessorKey: 'status',
        cell: ({ getValue }) => {
            const value = getValue() as string
            const color = statusColorMap[value] || 'bg-gray-100 text-gray-800'
            return (
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${color}`}>
                    {value}
                </span>
            )
        },
    },
]

const currencyOptions = ['BTC', 'ETH', 'USDT']

const Page = () => {
    const [selectedCurrency, setSelectedCurrency] = useState<string>('BTC')
    const [showStatus, setShowStatus] = useState(false)
    const [showModal, setShowModal] = useState(false)
    const searchParams = useSearchParams()
    const router = useRouter()

    useEffect(() => {
        if (searchParams.get('isdone') === 'success') {
            setShowStatus(true)
        }
    }, [searchParams])

    const handleDeposit = () => {
        setShowStatus(true)
    }

    const handleConfirmPaid = () => {
        setShowModal(true)
    }

    const handleModalOk = () => {
        setShowModal(false)
        setShowStatus(false)
        router.push('/deposit/crypto')
    }

    const handleSelect = (key: string) => {
        setSelectedCurrency(key)
    }

    return (
        <>
            {/* Form OR Deposit Details */}
            <div className="lg:w-[70%] mx-auto p-6 bg-white dark:bg-gray-900 shadow rounded-lg space-y-4 font-inter">
                {!showStatus ? (
                    <>
                        <h2 className="text-lg font-bold mb-4">Deposit Form</h2>

                        <div className="grid grid-cols-2 items-center gap-2">
                            <label className="col-span-1 text-base font-semibold">Currency</label>
                            <Dropdown
                                title={selectedCurrency}
                                trigger="click"
                                placement="bottom-start"
                                toggleClassName="border border-gray-400 rounded-lg w-full"
                            >
                                {currencyOptions.map((cur) => (
                                    <DropdownItem
                                        key={cur}
                                        className="text-center w-full"
                                        eventKey={cur}
                                        onSelect={handleSelect}
                                    >
                                        {cur}
                                    </DropdownItem>
                                ))}
                            </Dropdown>
                        </div>

                        <div className="grid grid-cols-2 items-center gap-2">
                            <label className="col-span-1 text-base font-semibold">Amount</label>
                            <Input placeholder="0.000" className="w-full" />
                        </div>

                        <div className="grid grid-cols-2 items-center gap-2">
                            <label className="col-span-1 text-base font-semibold">Total</label>
                            <Input placeholder="0.000" className="w-full" />
                        </div>

                        <Button size="sm" onClick={handleDeposit} variant="solid" className="rounded-lg w-full">
                            Deposit
                        </Button>
                    </>
                ) : (
                    <>
                        <div className="flex flex-row gap-6">
                            <div className="w-[30%]">
                                <div className="text-lg font-semibold pb-2">BTC Address</div>
                                <Image
                                    src="/img/others/1.png"
                                    width={300}
                                    height={300}
                                    alt="btc address image"
                                />
                            </div>
                            <div className="w-full">
                                <h2 className="text-lg font-bold">Deposit Details</h2>
                                <hr className="my-4 border-2 border-primary" />
                                <div className="grid grid-cols-[150px_1fr] gap-y-3 text-sm">
                                    <div className="text-xs font-semibold">BTC ADDRESS:</div>
                                    <div><code>1BQV2E2GNGqWjStzdoCi2ijVLXNZodXEY7</code></div>

                                    <div className="text-xs font-semibold">AMOUNT IN ASSET:</div>
                                    <div>0.0009697 BTC</div>

                                    <div className="text-xs font-semibold">AMOUNT IN USD:</div>
                                    <div>$100.00</div>

                                    <div className="text-xs font-semibold">STATUS:</div>
                                    <div>
                                        <span className="bg-yellow-200 text-yellow-800 px-2 py-1 rounded">Pending</span>
                                    </div>
                                </div>

                                <Button className="w-full mt-4 bg-primary rounded-lg" size="sm" variant="solid" onClick={handleConfirmPaid}>
                                    Confirm Paid
                                </Button>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* Table Always Visible */}
            <div className="mt-10 p-6 bg-white dark:bg-gray-900 rounded-lg shadow">
                <h2 className="text-lg font-bold mb-4">Recent Transactions</h2>
                <DataTable
                    data={transactions}
                    columns={columns}
                    selectable={true}
                    pagingData={{
                        total: transactions.length,
                        pageIndex: 1,
                        pageSize: 10,
                    }}
                />
            </div>

            {/* Confirmation Modal */}
            {showModal && (
                <Dialog onClose={() => setShowModal(false)} isOpen width={400}>
                    <div className="space-y-4">
                        <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900 p-2 flex items-center justify-center mx-auto mb-3.5">
                            <svg aria-hidden="true" className="w-12 h-12 text-green-500 dark:text-green-400" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg>
                            <span className="sr-only">Success</span>
                        </div>
                        <div className="text-center font-semibold text-xl">Your payment is in processing.</div>
                        <div className="flex items-center justify-center">
                            <Button onClick={handleModalOk} size="sm" variant="solid" className="px-6 rounded-lg">Close</Button>
                        </div>
                    </div>
                </Dialog>
            )}
        </>
    )
}

export default Page
