'use client'

import React, { useState } from 'react'
import { ColumnDef } from '@/components/shared/DataTable'
import DataTable from '@/components/shared/DataTable'
import { FaEdit, FaMoneyBillWave } from 'react-icons/fa'
import { Button } from '@/components/ui'

type Invoice = {
    id: number
    invoiceFrom: string
    invoiceTo: string
    payout: number
    currency: string
    date: string
    dueDate: string
    paymentTransfer: string
    totalAmount: number
    status: 'Paid' | 'Unpaid' | 'Pending'
}

const initialInvoices: Invoice[] = [
    {
        id: 1001,
        invoiceFrom: 'Company A',
        invoiceTo: 'Client X',
        payout: 1500,
        currency: 'USD',
        date: '2025-06-01',
        dueDate: '2025-06-15',
        paymentTransfer: 'Bank Transfer',
        totalAmount: 1500,
        status: 'Pending',
    },
    {
        id: 1002,
        invoiceFrom: 'Company B',
        invoiceTo: 'Client Y',
        payout: 2000,
        currency: 'EUR',
        date: '2025-06-02',
        dueDate: '2025-06-16',
        paymentTransfer: 'PayPal',
        totalAmount: 2000,
        status: 'Paid',
    },
    // مزید invoices شامل کریں
]

const InvoiceTable = () => {
    const [data, setData] = useState<Invoice[]>(initialInvoices)

    const handleEdit = (row: Invoice) => {
        console.log(`Edit invoice with ID: ${row.id}`)
    }

    const handlePay = (row: Invoice) => {
        console.log(`Pay invoice with ID: ${row.id}`)
    }

    const columns: ColumnDef<Invoice>[] = [
        {
            header: 'Invoice No',
            accessorKey: 'id',
            cell: ({ row }) => `#${row.original.id}`,
        },
        {
            header: 'Invoice From',
            accessorKey: 'invoiceFrom',
        },
        {
            header: 'Invoice To',
            accessorKey: 'invoiceTo',
        },
        {
            header: 'Payout',
            accessorKey: 'payout',
            cell: ({ row }) => row.original.payout.toFixed(2),
        },
        {
            header: 'Currency',
            accessorKey: 'currency',
        },
        {
            header: 'Date',
            accessorKey: 'date',
        },
        {
            header: 'Due Date',
            accessorKey: 'dueDate',
        },
        {
            header: 'Payment Transfer',
            accessorKey: 'paymentTransfer',
        },
        {
            header: 'Total Amount',
            accessorKey: 'totalAmount',
            cell: ({ row }) => row.original.totalAmount.toFixed(2),
        },
        {
            header: 'Status',
            accessorKey: 'status',
            cell: ({ row }) => {
                const status = row.original.status
                let bg = ''
                let text = ''

                switch (status) {
                    case 'Paid':
                        bg = 'bg-green-200'
                        text = 'text-green-900'
                        break
                    case 'Unpaid':
                        bg = 'bg-red-200'
                        text = 'text-red-900'
                        break
                    case 'Pending':
                        bg = 'bg-yellow-200'
                        text = 'text-yellow-900'
                        break
                    default:
                        bg = 'bg-gray-100'
                        text = 'text-gray-800'
                }

                return (
                    <span className={`text-xs px-2 py-1 rounded ${bg} ${text}`}>
                        {status}
                    </span>
                )
            },
        },
        {
            header: 'Action',
            id: 'action',
            cell: ({ row }) => (
                <Button
                    size="xs"
                    className=""
                    onClick={() => handleEdit(row.original)}
                >
                    <FaEdit size={12} />
                </Button>
            ),
        },
        {
            header: 'Pay',
            id: 'pay',
            cell: ({ row }) => (
                <Button
                    size="xs"
                    className="border border-green-600 text-green-600 hover:bg-green-600 hover:text-white"
                    onClick={() => handlePay(row.original)}
                >
                    <FaMoneyBillWave size={12} />
                </Button>
            ),
        },
    ]

    return (
        <div className="bg-white dark:bg-gray-900  shadow rounded-lg p-5">
            <div>
                <div className='text-xl font-semibold'>
                    Invoices
                </div>

                <hr className='my-4' />
                <div>
                    <DataTable
                        columns={columns}
                        data={data}
                        pagingData={{
                            total: data.length,
                            pageIndex: 1,
                            pageSize: 10,
                        }}
                    />
                </div>
            </div>
        </div>
    )
}

export default InvoiceTable
