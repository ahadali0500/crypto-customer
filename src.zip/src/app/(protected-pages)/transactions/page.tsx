'use client'

import React, { useState } from 'react'
import { ColumnDef } from '@/components/shared/DataTable'
import DataTable from '@/components/shared/DataTable'
import { Checkbox } from '@/components/ui'

type Transaction = {
    id: number
    type: string
    date: string
    baseAsset: string
    amountBTC: string
    amountUSD: string
    feePercent: string
    status: 'Processing' | 'Success' | 'Failed'
}

const initialTransactions: Transaction[] = [
    {
        id: 1546,
        type: 'Deposit',
        date: '2024-12-18',
        baseAsset: 'BTC',
        amountBTC: '+0.0049480 BTC',
        amountUSD: '$500.00',
        feePercent: '0%',
        status: 'Processing',
    },
    {
        id: 1547,
        type: 'Deposit',
        date: '2024-12-12',
        baseAsset: 'BTC',
        amountBTC: '+0.0346431 BTC',
        amountUSD: '$3500.00',
        feePercent: '0%',
        status: 'Success',
    },
   
]

const TransactionTable = () => {
    const [data, setData] = useState<Transaction[]>(initialTransactions)
    const [selectedRows, setSelectedRows] = useState<number[]>([])

    const handleCheckBoxChange = (checked: boolean, row: Transaction) => {
        if (checked) {
            setSelectedRows((prev) => [...prev, row.id])
        } else {
            setSelectedRows((prev) => prev.filter((id) => id !== row.id))
        }
    }

    const handleIndeterminateCheckboxChange = (
        checked: boolean,
        rows: any[],
    ) => {
        if (checked) {
            setSelectedRows(rows.map((row) => row.original.id))
        } else {
            setSelectedRows([])
        }
    }

    const checkboxChecked = (row: Transaction) => selectedRows.includes(row.id)

    const indeterminateCheckboxChecked = (rows: any[]) =>
        rows.length > 0 && rows.every((r) => selectedRows.includes(r.original.id))

    const columns: ColumnDef<Transaction>[] = [
        {
            accessorKey: 'id',
            header: 'ID',
            cell: ({ row }) => `#${row.original.id}`,
        },
        {
            accessorKey: 'type',
            header: 'Type',
        },
        {
            accessorKey: 'date',
            header: 'Date',
        },
        {
            accessorKey: 'baseAsset',
            header: 'Base Asset',
        },
        {
            accessorKey: 'amountBTC',
            header: 'Amount (BTC)',
        },
        {
            accessorKey: 'amountUSD',
            header: 'Amount (USD)',
            cell:({row})=>{
                const amount = row.original.amountUSD
            return <span className='text-green-400'>{amount}</span>
            }
        },
        {
            accessorKey: 'feePercent',
            header: 'Fee %',
        },
        {
            accessorKey: 'status',
            header: 'Status',
            cell: ({ row }) => {
                const status = row.original.status
                let color = ''
                switch (status) {
                    case 'Success':
                        color = 'text-green-600 bg-green-300 ';
                        break
                    case 'Processing':
                        color = 'text-yellow-600 bg-yellow-300'
                        break
                    case 'Failed':
                        color = 'text-red-600 bg-red-300'
                        break
                    default:
                        color = 'text-gray-600 bg-gray-300'
                }
                return <span className={`text-xs font-semibold py-1 px-2 rounded-xl ${color}`}>{status}</span>
            },
        },
    ]

    return (
        <div className="bg-white dark:bg-gray-900 shadow rounded-lg p-5">
            <DataTable
                columns={columns}
                data={data}
                selectable
                checkboxChecked={checkboxChecked}
                indeterminateCheckboxChecked={indeterminateCheckboxChecked}
                onCheckBoxChange={handleCheckBoxChange}
                onIndeterminateCheckBoxChange={handleIndeterminateCheckboxChange}
                pagingData={{
                    total: data.length,
                    pageIndex: 1,
                    pageSize: 10,
                }}
            />
        </div>
    )
}

export default TransactionTable
