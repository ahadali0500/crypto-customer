'use client';
import React, { useState } from 'react';
import TabList from '@/components/ui/Tabs/TabList';
import Tabs from '@/components/ui/Tabs/Tabs';
import TabNav from '@/components/ui/Tabs/TabNav';
import TabContent from '@/components/ui/Tabs/TabContent';
import Dropdown from '@/components/ui/Dropdown/Dropdown';
import DropdownItem from '@/components/ui/Dropdown/DropdownItem';
import { Button, Dialog, Input } from '@/components/ui';
import { CheckCircle2 } from 'lucide-react';

// ✅ Simple Dialog Component (replace this with your own Dialog if available)
// const Dialog = ({ open, onClose, children }: { open: boolean, onClose: () => void, children: React.ReactNode }) => {
//   if (!open) return null;
//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
//       <div className="bg-white dark:bg-gray-900 p-6 rounded-xl shadow-lg w-[90%] max-w-md relative">
//         {children}
//         <button onClick={onClose} className="absolute top-2 right-3 text-gray-500 hover:text-gray-700 text-lg">&times;</button>
//       </div>
//     </div>
//   );
// };

const Page = () => {
  const currencyOptions = ['BTC', 'ETH', 'USDT'];
  const [selectedCurrency, setSelectedCurrency] = useState<string>('BTC');
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);

  const handleSelect = (key: string) => {
    setSelectedCurrency(key);
  };

  const handleExchangeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setDialogOpen(true);
  };

  return (
    <>
      <div className='p-5'>
        <div className='flex items-center justify-center'>
          <div className='w-full md:w-[60%] bg-white dark:bg-gray-900 p-6 rounded-2xl'>
            <Tabs defaultValue='locked'>
              <TabList>
                <TabNav value='locked'>Locked</TabNav>
                <TabNav value='available'>Available</TabNav>
              </TabList>

              {['locked', 'available'].map((tab) => (
                <TabContent key={tab} value={tab}>
                  <form>
                    <div className='flex flex-row items-center gap-4 mt-4'>
                      <div className='w-full'>
                        <label className='font-semibold text-base'>Sell asset:</label>
                        <Dropdown
                          title={selectedCurrency}
                          trigger="click"
                          placement="bottom-start"
                          toggleClassName="border border-gray-400 rounded-lg w-full"
                          menuClass='w-full'
                        >
                          {currencyOptions.map((cur) => (
                            <DropdownItem
                              key={cur}
                              className="text-center w-full"
                              eventKey={cur}
                              onSelect={handleSelect}
                            >
                              {cur}
                            </DropdownItem>
                          ))}
                        </Dropdown>
                      </div>

                      <div className='w-full'>
                        <label className='font-semibold text-base'>Buy asset:</label>
                        <Dropdown
                          title={selectedCurrency}
                          trigger="click"
                          placement="bottom-start"
                          toggleClassName="border border-gray-400 rounded-lg w-full"
                          menuClass='w-full'
                        >
                          {currencyOptions.map((cur) => (
                            <DropdownItem
                              key={cur}
                              className="text-center w-full"
                              eventKey={cur}
                              onSelect={handleSelect}
                            >
                              {cur}
                            </DropdownItem>
                          ))}
                        </Dropdown>
                      </div>
                    </div>

                    <div className='flex items-center gap-2 mt-4 bg-gray-100 dark:bg-gray-700 pl-3 rounded-lg'>
                      <span className='whitespace-nowrap text-base'>Sell amount</span>
                      <Input className='border-0 focus:ring-0 bg-gray-200 dark:bg-gray-800 rounded-lg' placeholder='0.000000' />
                    </div>

                    <div className='flex items-center gap-2 mt-4 bg-gray-100 dark:bg-gray-700 pl-3 rounded-lg'>
                      <span className='whitespace-nowrap text-base'>Buy amount</span>
                      <Input className='border-0 focus:ring-0 bg-gray-200 dark:bg-gray-800 rounded-lg' placeholder='0.000000' />
                    </div>

                    <hr className='text-primary bg-primary my-8' />

                    <div className='space-y-2'>
                      <div className='flex flex-row items-center justify-between gap-4'>
                        <div>Transaction Fees (4%)</div>
                        <div>($ 0.0)</div>
                      </div>
                      <div className='flex flex-row items-center justify-between gap-4'>
                        <div>Total sell amount:</div>
                        <div>($ 0.0)</div>
                      </div>
                      <div className='flex flex-row items-center justify-between gap-4'>
                        <div>{tab === 'locked' ? 'Total pay amount:' : 'You receive:'}</div>
                        <div>($ 0.0)</div>
                      </div>
                      <div className='text-primary my-2'>Max sum</div>
                    </div>

                    <div className='w-full mt-4'>
                      <Button
                        variant='solid'
                        className='rounded-lg w-full'
                        size='sm'
                        onClick={handleExchangeClick}
                      >
                        Exchange
                      </Button>
                    </div>
                  </form>
                </TabContent>
              ))}
            </Tabs>
          </div>
        </div>
      </div>

      {/* ✅ Success Dialog */}
      <Dialog isOpen={dialogOpen} onClose={() => setDialogOpen(false)}>
        <div className='text-center'>
          <CheckCircle2 className='text-green-500 mx-auto mb-4' size={60} />
          <h3 className='text-xl font-semibold'>Exchange transaction have been successfully updated.</h3>
        </div>
      </Dialog>
    </>
  );
};

export default Page;
