'use client';

import React from 'react';
import Graph from '../Graph';
import DataTable, { ColumnDef } from '@/components/shared/DataTable';

type Transaction = {
  id: string;
  type: string;
  date: string;
  baseAsset: string;
  amount: string;
  fee: string;
  status: 'Success' | 'Pending';
};

const tickets: Transaction[] = [
  {
    id: 'TX001',
    type: 'Sell',
    date: '2025-06-05',
    baseAsset: 'BTC',
    amount: '0.05',
    fee: '0.002',
    status: 'Success',
  },
  {
    id: 'TX002',
    type: 'Buy',
    date: '2025-06-03',
    baseAsset: 'ETH',
    amount: '1.2',
    fee: '0.01',
    status: 'Pending',
  },
];

const statusColorMap: Record<Transaction['status'], string> = {
  Success: 'bg-green-500 text-white',
  Pending: 'bg-yellow-400 text-black',
};

const columns: ColumnDef<Transaction>[] = [
  { header: 'ID', accessorKey: 'id', cell: ({ row }) => <span>{row.original.id}</span> },
  { header: 'Type', accessorKey: 'type', cell: ({ row }) => <span>{row.original.type}</span> },
  { header: 'Date', accessorKey: 'date', cell: ({ row }) => <span>{row.original.date}</span> },
  { header: 'Asset', accessorKey: 'baseAsset', cell: ({ row }) => <span>{row.original.baseAsset}</span> },
  { header: 'Amount', accessorKey: 'amount', cell: ({ row }) => <span>{row.original.amount}</span> },
  { header: 'Fee', accessorKey: 'fee', cell: ({ row }) => <span>{row.original.fee}</span> },
  {
    header: 'Status',
    accessorKey: 'status',
    cell: ({ row }) => {
      const status = row.original.status;
      return (
        <span className={`text-xs font-semibold px-2 py-1 rounded ${statusColorMap[status]}`}>
          {status}
        </span>
      );
    },
  },
];

const Page = () => {
  return (
    <div className='min-h-screen'>
      {/* Remove overflow-y-auto from here */}
     <div className="h-[500px] mb-10">
  <Graph />
</div>


      <div className='p-6 bg-white dark:bg-gray-900 rounded-lg'>
        <h2 className="text-xl font-semibold mb-4">Tickets</h2>
        <DataTable
          data={tickets}
          columns={columns}
          pagingData={{
            total: tickets.length,
            pageIndex: 1,
            pageSize: 10,
          }}
        />
      </div>
    </div>
  );
};

export default Page;
