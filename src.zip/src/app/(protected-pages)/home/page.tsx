const Page = () => {
    return <div>Home page</div>
}

export default Page
