"use client"

import React, { useState } from "react"
import { Button } from "@/components/ui"
import RichTextEditor from "@/components/shared/RichTextEditor"
import classNames from "classnames"

interface Message {
  id: number
  text: string
  sender: "user" | "other"
  name: string
  timestamp: Date
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hey! How are you doing?",
      sender: "other",
      name: "Ahmed",
      timestamp: new Date("2024-01-15T10:30:00"),
    },
    {
      id: 2,
      text: "I'm doing great! Just finished my work. What about you?",
      sender: "user",
      name: "You",
      timestamp: new Date("2024-01-15T10:32:00"),
    },
    {
      id: 3,
      text: "That's awesome! I'm planning to go out for dinner tonight.",
      sender: "other",
      name: "Ahmed",
      timestamp: new Date("2024-01-15T10:35:00"),
    },
    {
      id: 4,
      text: "Sounds fun! Where are you planning to go?",
      sender: "user",
      name: "You",
      timestamp: new Date("2024-01-15T10:36:00"),
    },
    {
      id: 5,
      text: "There's this new restaurant downtown. Want to join?",
      sender: "other",
      name: "Ahmed",
      timestamp: new Date("2024-01-15T10:38:00"),
    },
    {
      id: 6,
      text: "I'd love to. What time should we meet?",
      sender: "user",
      name: "You",
      timestamp: new Date("2024-01-15T10:40:00"),
    },
    {
      id: 7,
      text: "There's this new restaurant downtown. Want to join?",
      sender: "other",
      name: "Ahmed",
      timestamp: new Date("2024-01-15T10:38:00"),
    },
    {
      id: 8,
      text: "I'd love to. What time should we meet?",
      sender: "user",
      name: "You",
      timestamp: new Date("2024-01-15T10:40:00"),
    },
  ])

  const [newMessage, setNewMessage] = useState("")

  const formatTime = (date: Date) =>
    date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })

  const formatDate = (date: Date) => {
    const today = new Date()
    const messageDate = new Date(date)

    if (messageDate.toDateString() === today.toDateString()) return "Today"

    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (messageDate.toDateString() === yesterday.toDateString())
      return "Yesterday"

    return messageDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const sendMessage = () => {
    const plainText = newMessage.replace(/<[^>]+>/g, "").trim()
    if (plainText) {
      const message: Message = {
        id: messages.length + 1,
        text: newMessage,
        sender: "user",
        name: "You",
        timestamp: new Date(),
      }
      setMessages([...messages, message])
      setNewMessage("")
    }
  }

  const handleEditorChange = (content: {
    text: string
    html: string
    json: any
  }) => {
    setNewMessage(content.html)
  }

  return (
    <div className="flex flex-col h-screen bg-gray-100 dark:bg-gray-900">
      {/* Chat messages */}
      <div className="flex-1 h-screen overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => {
          const showDate =
            index === 0 ||
            formatDate(message.timestamp) !==
              formatDate(messages[index - 1].timestamp)

          return (
            <div key={message.id}>
              {showDate && (
                <div className="text-center text-xs text-gray-500 dark:text-gray-400 mb-2">
                  {formatDate(message.timestamp)}
                </div>
              )}

              <div
                className={`flex ${
                  message.sender === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={classNames(
                    "max-w-xs lg:max-w-md px-4 py-3 rounded-2xl shadow-sm break-words",
                    "prose prose-sm dark:prose-invert",
                    message.sender === "user"
                      ? "bg-primary text-white dark:text-white"
                      : "bg-gray-100 text-gray-900 dark:bg-gray-800 dark:text-gray-100 border border-gray-300 dark:border-gray-600"
                  )}
                >
                  <div
                    className={classNames(
                      "text-xs font-medium mb-1",
                      message.sender === "user"
                        ? "text-white/70"
                        : "text-gray-500 dark:text-gray-400"
                    )}
                  >
                    {message.name}
                  </div>
                  <div
                    className="text-sm"
                    dangerouslySetInnerHTML={{ __html: message.text }}
                  />
                  <div
                    className={classNames(
                      "text-xs mt-1",
                      message.sender === "user"
                        ? "text-white/70"
                        : "text-gray-400 dark:text-gray-500"
                    )}
                  >
                    {formatTime(message.timestamp)}
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Input area */}
      <div className="bg-white dark:bg-gray-950 border-t border-gray-200 dark:border-gray-700 p-4">
        <div className="space-y-2">
          <RichTextEditor
            onChange={handleEditorChange}
            editorContentClass="min-h-[150px]"
          />
          <div className="flex justify-end">
            <Button onClick={sendMessage} variant="solid">
              Send Message
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
