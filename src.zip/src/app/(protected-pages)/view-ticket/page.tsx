'use client'

import React from 'react'
import DataTable, { ColumnDef } from '@/components/shared/DataTable'
import { Button } from '@/components/ui'

// Ticket type definition
type Ticket = {
  id: number
  subject: string
  date: string
  status: 'Solved' | 'Pending'
}

// Dummy ticket data
const tickets: Ticket[] = [
  {
    id: 1,
    subject: 'this is testing',
    date: '21/09/2024',
    status: 'Solved',
  },
  {
    id: 2,
    subject: 'testing',
    date: '25/05/2025',
    status: 'Solved',
  },
  {
    id: 3,
    subject: 'ahad',
    date: '29/05/2025',
    status: 'Pending',
  },
]

// Badge color map
const statusColorMap: Record<string, string> = {
  Solved: 'bg-lime-600 text-white',
  Pending: 'bg-yellow-400 text-white',
}

// Columns for the ticket table
const columns: ColumnDef<Ticket>[] = [
  {
    header: 'Ticket No',
    accessorKey: 'id',
    cell: ({ row }) => <span>{row.original.id}</span>,
  },
  {
    header: 'View',
    id: 'view',
    cell: () => (
      <Button size='xs' variant='solid' className=" px-2 py-0.5 text-[10px] font-normal rounded-lg">
        View Detail
      </Button>
    ),
  },
  {
    header: 'Subject',
    accessorKey: 'subject',
  },
  {
    header: 'Date',
    accessorKey: 'date',
  },
  {
    header: 'Status',
    accessorKey: 'status',
    cell: ({ getValue }) => {
      const value = getValue() as string
      const color = statusColorMap[value] || 'bg-gray-300 text-black'
      return (
        <span
          className={`text-[10px] px-3 py-1 rounded-full font-semibold ${color}`}
        >
          {value}
        </span>
      )
    },
  },
]

const TicketTablePage = () => {
  return (
    <div className="p-6  bg-white dark:bg-gray-900 rounded-lg">
      <div className=" rounded-lg  ">
        <h2 className="text-xl font-semibold mb-4">Tickets</h2>
        <DataTable
          data={tickets}
          columns={columns}
          pagingData={{
            total: tickets.length,
            pageIndex: 1,
            pageSize: 10,
          }}
        />
      </div>
    </div>
  )
}

export default TicketTablePage
